AM 6 Cinematic LUTs

Included LUTs:
1. Soft Gold
2. Moody Teal
3. Film Clean
4. Dark Cinema
5. Warm Tone
6. Natural Light

Compatible:
- Premiere Pro
- After Effects
- DaVinci Resolve
- Final Cut Pro
- CapCut (Desktop)

Format:
.CUBE
